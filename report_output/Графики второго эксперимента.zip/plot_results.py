"""Four Python plots of the supplied screenshot, not the project's latest CSV.

Uses the installed ReportLab plotting library; does not install dependencies.
Inputs: snapshot_threads.csv, snapshot_main.csv, snapshot_analysis.csv.
Output: graphs.pdf (four vector pages) and four annotated PNG images.
Set PDFTOPPM to the full Poppler executable path if it is not on PATH.
"""
from pathlib import Path
from decimal import Decimal as D, getcontext
import csv
import math
import os
import shutil
import subprocess

from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas
from reportlab.graphics import renderPDF
from reportlab.graphics.shapes import Drawing, Rect, String, Line, Circle, Polygon
from reportlab.graphics.charts.lineplots import LinePlot
from reportlab.graphics.charts.axes import LogYValueAxis

ROOT = Path(__file__).resolve().parent
getcontext().prec = 60
REFERENCE = D('0.450968550322326660168633675195179549577893014459770257519547')
N = 20000000
WIDTH, HEIGHT = 1200, 780
BLUE = colors.HexColor('#1261A0')
ORANGE = colors.HexColor('#CC5A13')
GREEN = colors.HexColor('#237744')
GRAY = colors.HexColor('#59677A')
DARK = colors.HexColor('#17324D')
GRID = colors.HexColor('#DCE4EB')

font_dir = Path(os.environ.get('WINDIR', 'C:/Windows')) / 'Fonts'
pdfmetrics.registerFont(TTFont('Plot', str(font_dir / 'arial.ttf')))
pdfmetrics.registerFont(TTFont('PlotBold', str(font_dir / 'arialbd.ttf')))

def read(name):
    with (ROOT / name).open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream))

threads = read('snapshot_threads.csv')
main = read('snapshot_main.csv')
analysis = read('snapshot_analysis.csv')
TECHS = ('POSIX', 'std::thread')
COLORS = (BLUE, ORANGE)
groups = [[r for r in threads if r['technology'] == tech] for tech in TECHS]
assert all([int(r['thread_id']) for r in g] == list(range(1, 11)) for g in groups)
assert [int(r['threads']) for r in main] == [1, 4, 4]
assert all(D(r['compute_seconds']) <= D(r['total_seconds']) for r in threads)
baseline = D(main[0]['seconds'])
speed = [float(baseline / D(r['seconds'])) for r in main[1:]]
errors = [float(abs(REFERENCE - D(r['result']))) for r in main]
analysis_errors = [float(abs(REFERENCE - D(r['result']))) for r in analysis]
assert all(value > 0 for value in speed)
assert errors[0] == errors[1] == errors[2]
assert all(error == errors[0] for error in analysis_errors)
assert [int(r['threads']) for r in analysis] == [10, 10]
assert all(D(r['seconds']) == D(groups[i][0]['total_seconds']) for i, r in enumerate(analysis))

def ru(value, digits=5):
    return f'{value:.{digits}f}'.replace('.', ',')

def text(d, x, y, value, size=15, color=DARK, anchor='start', bold=False):
    d.add(String(x, y, value, fontName='PlotBold' if bold else 'Plot',
                 fontSize=size, fillColor=color, textAnchor=anchor))

def base(title, subtitle):
    d = Drawing(WIDTH, HEIGHT)
    d.add(Rect(0, 0, WIDTH, HEIGHT, fillColor=colors.white, strokeColor=None))
    text(d, 38, 735, title, 26, bold=True)
    text(d, 38, 703, subtitle, 16, color=GRAY)
    text(d, 38, 25, 'Источник: приложенный скриншот. N = 20 000 000. Однократные измерения.', 13, color=GRAY)
    return d

def axes(d, data, xmin, xmax, ymin, ymax, ysteps, ytitle,
         xtitle, logarithmic=False, xsteps=None, yformat=None):
    lp = LinePlot()
    lp.x, lp.y, lp.width, lp.height = 100, 155, 1030, 470
    lp.data = data
    lp.joinedLines = True
    if logarithmic:
        lp.yValueAxis = LogYValueAxis()
    for axis in (lp.xValueAxis, lp.yValueAxis):
        axis.labels.fontName = 'Plot'
        axis.labels.fontSize = 14
        axis.strokeColor = GRAY
    lp.xValueAxis.valueMin, lp.xValueAxis.valueMax = xmin, xmax
    lp.xValueAxis.valueSteps = xsteps or list(range(int(xmin), int(xmax) + 1))
    lp.yValueAxis.valueMin, lp.yValueAxis.valueMax = ymin, ymax
    lp.yValueAxis.valueSteps = ysteps
    lp.yValueAxis.labelTextFormat = yformat or (lambda value: str(value).replace('.', ','))
    lp.xValueAxis.labelTextFormat = lambda value: str(int(value))
    lp.yValueAxis.visibleGrid = True
    lp.yValueAxis.gridStrokeColor = GRID
    lp.yValueAxis.gridStrokeWidth = .7
    for i in range(len(data)):
        lp.lines[i].strokeColor = COLORS[i % 2]
        lp.lines[i].strokeWidth = 2
        lp.lines[i].symbol = None
    d.add(lp)
    text(d, 100, 651, ytitle, 15, color=GRAY)
    text(d, 1130, 112, xtitle, 15, color=GRAY, anchor='end')
    X = lambda value: lp.x + (value - xmin) / (xmax - xmin) * lp.width
    if logarithmic:
        Y = lambda value: lp.y + math.log(value / ymin) / math.log(ymax / ymin) * lp.height
    else:
        Y = lambda value: lp.y + (value - ymin) / (ymax - ymin) * lp.height
    return lp, X, Y

def marker(d, x, y, color, shape='circle', radius=5, hollow=False):
    fill = colors.white if hollow else color
    if shape == 'square':
        d.add(Rect(x-radius, y-radius, 2*radius, 2*radius,
                   fillColor=fill, strokeColor=color, strokeWidth=2))
    else:
        d.add(Circle(x, y, radius, fillColor=fill, strokeColor=color, strokeWidth=2))

def legend(d, entries):
    for i, (name, color, shape) in enumerate(entries):
        x = 100 + i * 330
        marker(d, x + 7, 76, color, shape)
        text(d, x + 25, 71, name, 16, color=color)

def callout(d, point, label_point, label, color, anchor='middle'):
    x, y = point
    lx, ly = label_point
    d.add(Line(x, y, lx, ly-4, strokeColor=color, strokeWidth=.9))
    label_width = pdfmetrics.stringWidth(label, 'PlotBold', 15)
    left = lx - label_width/2 if anchor == 'middle' else lx
    if anchor == 'end': left = lx - label_width
    d.add(Rect(left-5, ly-4, label_width+10, 21,
               fillColor=colors.white, strokeColor=None))
    text(d, lx, ly, label, 15, color=color, anchor=anchor, bold=True)

def distribution(efficiency=False):
    if efficiency:
        values = [[float(D(r['compute_seconds']) / D(r['total_seconds']) * 100)
                   for r in group] for group in groups]
        title = '3. Эффективность каждого рабочего потока'
        subtitle = 'Время вычислительного участка / полное время расчёта технологии × 100 %'
        ymax, steps, ytitle = 105, [0,20,40,60,80,100], 'Эффективность потока, %'
        label = lambda value: ru(value, 2)
        yformat = lambda value: ru(value, 0)
    else:
        values = [[float(D(r['compute_seconds']) * 1000) for r in group] for group in groups]
        title = '1. Время вычислений каждого рабочего потока'
        subtitle = '10 рабочих потоков; по 2 млн прямоугольников на поток; POSIX и std::thread'
        ymax, steps, ytitle = 125, [0,20,40,60,80,100,120], 'Время вычислительного участка, мс'
        label = lambda value: ru(value, 4)
        yformat = lambda value: ru(value, 1)
    d = base(title, subtitle)
    data = [[(i+1, value) for i, value in enumerate(series)] for series in values]
    lp, X, Y = axes(d, data, 1, 10, 0, ymax, steps, ytitle, 'Номер рабочего потока', yformat=yformat)
    for api, (color, series) in enumerate(zip(COLORS, values)):
        for t, value in enumerate(series, 1):
            marker(d, X(t), Y(value), color, 'square' if api else 'circle')
            other = values[1-api][t-1]
            above = value > other or (value == other and api == 0)
            text(d, X(t), Y(value)+(16 if above else -25), label(value),
                 15, color=color, anchor='middle', bold=True)
    legend(d, [('POSIX', BLUE, 'circle'), ('std::thread', ORANGE, 'square')])
    if efficiency:
        text(d, 38, 46, 'Проценты рассчитаны по исходным временам и округлены до 0,01 %. Это не загрузка CPU.', 13, color=GRAY)
    else:
        text(d, 38, 46, '1 мс = 0,001 с. Здесь показан вычислительный участок, без создания и ожидания потоков.', 13, color=GRAY)
    return d

def acceleration():
    d = base('2. Ускорение программы и идеальное ускорение',
             'N = 20 000 000; основной расчёт: p = 4; база p = 1 — последовательный цикл')
    lp, X, Y = axes(d, [[(4,speed[0])],[(4,speed[1])],[(p,p) for p in range(1,5)]],
                    1,4,0,5.5,[0,1,2,3,4,5], 'Ускорение S(p) = Tпосл / T(p)',
                    'Количество рабочих потоков p')
    lp.lines[2].strokeColor=GREEN
    lp.lines[2].strokeDashArray=[7,4]
    for p in range(1,5):
        marker(d,X(p),Y(p),GREEN,hollow=True)
        text(d,X(p)+(15 if p==1 else 0),Y(p)+18,f'Идеал: {p}',15,color=GREEN,
             anchor='start' if p==1 else 'middle')
    marker(d,X(1),Y(1),GRAY,radius=3)
    callout(d,(X(1),Y(1)),(X(1)+170,Y(1)-40),'Последовательный: 1,0000',GRAY)
    marker(d,X(4),Y(speed[0]),BLUE,radius=6)
    marker(d,X(4),Y(speed[1]),ORANGE,'square')
    callout(d,(X(4),Y(speed[0])),(X(4)-165,Y(speed[0])-32),'POSIX: '+ru(speed[0],7),BLUE)
    callout(d,(X(4),Y(speed[1])),(X(4)-165,Y(speed[1])+35),'std::thread: '+ru(speed[1],7),ORANGE)
    legend(d,[('POSIX',BLUE,'circle'),('std::thread',ORANGE,'square'),('Идеал S(p) = p',GREEN,'circle')])
    text(d,38,46,'При p = 2 и p = 3 измерений нет. Точки технологий не соединены вымышленной кривой.',13,color=GRAY)
    text(d,38,7,'Превышение ориентира 4 — результат одного замера; устойчивое сверхлинейное ускорение не установлено.',12,color=GRAY)
    return d

def accuracy():
    d=base('4. Точность результата и количество потоков',
           'N = 20 000 000; абсолютная погрешность относительно эталона; значения в единицах 10^(-8)')
    error=errors[0]/1e-8
    lp,X,Y=axes(d,[[(4,error),(10,error)],[(4,error),(10,error)],[(1,error)]],
                1,10,0,2.4,[0,.5,1,1.5,2], 'Абсолютная погрешность × 10^8',
                'Количество рабочих потоков p',yformat=lambda v:ru(v,1))
    for i in range(3): lp.lines[i].strokeColor=None
    label=ru(errors[0]*1e8,8)+' × 10^(-8)'
    marker(d,X(1),Y(error),GRAY,radius=7)
    callout(d,(X(1),Y(error)),(X(1)+170,Y(error)+100),'Последовательный: '+label,GRAY)
    for p in (4,10):
        marker(d,X(p),Y(error),BLUE,radius=11,hollow=True)
        marker(d,X(p),Y(error),ORANGE,'square',radius=5)
        lx=X(p)+(45 if p==4 else -110)
        callout(d,(X(p),Y(error)),(lx,Y(error)+55),'POSIX: '+label,BLUE)
        callout(d,(X(p),Y(error)),(lx,Y(error)-65),'std::thread: '+label,ORANGE)
    legend(d,[('POSIX',BLUE,'circle'),('std::thread',ORANGE,'square'),('Последовательный',GRAY,'circle')])
    text(d,38,46,'p = 4: основной расчёт; p = 10: анализ потоков. Все результаты совпадают до показанных знаков.',13,color=GRAY)
    text(d,38,7,'I_N = 0,450968532781073; I_эталон ≈ 0,45096855032232666; h = 1,5 × 10^(-7).',12,color=GRAY)
    return d

def main_plot():
    drawings = [distribution(), acceleration(), distribution(True), accuracy()]
    pdf = ROOT / 'graphs.pdf'
    output = canvas.Canvas(str(pdf), pagesize=(WIDTH,HEIGHT))
    output.setTitle('Четыре графика запуска N 20000000')
    for drawing in drawings:
        renderPDF.draw(drawing, output, 0, 0)
        output.showPage()
    output.save()
    bundled = Path.home()/'.cache/codex-runtimes/codex-primary-runtime/dependencies/native/poppler/Library/bin/pdftoppm.exe'
    poppler = os.environ.get('PDFTOPPM') or shutil.which('pdftoppm') or str(bundled)
    subprocess.run([poppler,'-r','144','-png',str(pdf),str(ROOT/'graph')],check=True,capture_output=True)
    names = ['01-thread-times.png','02-speedup.png','03-thread-efficiency.png','04-accuracy.png']
    for i,name in enumerate(names,1):
        (ROOT/f'graph-{i}.png').replace(ROOT/name)
    print('Created graphs.pdf and four PNG plots')
    print('Speedups:', *speed)
    print('Absolute error:', errors[0])

if __name__ == '__main__':
    main_plot()
